// -------------------------------------------------------------------
document.writeln("<html>");
document.writeln("<head>");
document.writeln("<title>�ޱ����ĵ�<\/title>");
document.writeln("<meta http-equiv=\"Content-Type\" content=\"text\/html; charset=gb2312\">");
document.writeln("<\/head>");
document.writeln("");
document.writeln("<body bgcolor=\"#FFFFFF\" text=\"#000000\" leftmargin=\"0\" topmargin=\"0\" marginwidth=\"0\" marginheight=\"0\">");
document.writeln("<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">");
document.writeln("  <tr> ");
document.writeln("    <td> ");
document.writeln("      <div align=\"center\"><object classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http:\/\/download.macromedia.com\/pub\/shockwave\/cabs\/flash\/swflash.cab#version=5,0,0,0\" width=\"190\" height=\"185\">");
document.writeln("          <param name=movie value=\"\/page_load_test\/tp5\/xinhuanet.com\/imgs.xinhuanet.com\/ad\/20010113_sygg_4.swf\">");
document.writeln("          <param name=quality value=high>");
document.writeln("          <embed src=\"\/page_load_test\/tp5\/xinhuanet.com\/imgs.xinhuanet.com\/ad\/20010113_sygg_4.swf\" quality=high pluginspage=\"http:\/\/www.macromedia.com\/shockwave\/download\/index.cgi?P1_Prod_Version=ShockwaveFlash\" type=\"application\/x-shockwave-flash\" width=\"190\" height=\"185\">");
document.writeln("          <\/embed> ");
document.writeln("        <\/object><\/div>");
document.writeln("    <\/td>");
document.writeln("  <\/tr>");
document.writeln("<\/table>");
document.writeln("<\/body>");
document.writeln("<\/html>");
// -------------------------------------------------------------------
