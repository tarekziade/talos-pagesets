var m=new Date().getMonth()+1;
var d=new Date().getDate();
if (m<10)
{m="0"+m;}
if (d<10)
{d="0"+d;}
void("<a href=http://www.people.com.cn/GB/historic\/"+m+d+" target=_blank class=aP2Red1>"+"[ʷ�Ͻ���]</a>");
