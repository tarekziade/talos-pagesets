/* move to prototype.js */
