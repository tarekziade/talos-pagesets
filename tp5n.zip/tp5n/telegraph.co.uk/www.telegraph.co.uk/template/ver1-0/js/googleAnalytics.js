function trackGoogle() {
	try {var pageTracker = _gat._getTracker("UA-7226372-1");pageTracker._trackPageview();} catch(err) {}
}

trackGoogle();