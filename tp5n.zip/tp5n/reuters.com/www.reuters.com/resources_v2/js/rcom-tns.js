if (!is_ipad && !is_iphone) {
  void('<link href="/resources_v2/css/rcom-tracknsave.css" rel="stylesheet" />');
  if (is_ie6) {
    void('<link href="/resources_v2/css/rcom-tracknsave-ie6.css" rel="stylesheet" />');
  }
  void('<scr' + 'ipt src="/resources_v2/js/rcom-tns-backend.js"></scr' + 'ipt>');
  void('<scr' + 'ipt src="/resources_v2/js/rcom-tns-frontend.js"></scr' + 'ipt>');
}
