void('<link href="/resources_v2/css/curtainSlider.css" rel="stylesheet" />');
void('<link href="/resources_v2/css/rcom-adHider.css" rel="alternate stylesheet" disabled="true" title="curtainSlider" />');
void('<link href="/resources_v2/css/rcom-adHider2.css" rel="alternate stylesheet" disabled="true"  title="alt2curtainSlider" />');
void('<scr' + 'ipt language="javascript" src="/resources_v2/js/libraries/yui_2_7_0/yahoo-dom-event/yahoo-dom-event.js"></scr' + 'ipt>');
void('<scr' + 'ipt language="javascript" src="/resources_v2/js/libraries/yui_2_7_0/animation/animation-min.js"></scr' + 'ipt>');
void('<scr' + 'ipt language="javascript" src="/resources_v2/js/libraries/yui_2_7_0/connection/connection-min.js"></scr' + 'ipt>');
void('<scr' + 'ipt language="javascript" src="/resources_v2/js/curtainSlider.js"></scr' + 'ipt>');