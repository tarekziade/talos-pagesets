var _baq = _baq || [];
_baq.push(['setClientId','E1ICVK']);
_baq.push(['trackPageView']);
(function () { var s = document.createElement('script'); s.src = ('../trb-1.js'; (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s); }());
