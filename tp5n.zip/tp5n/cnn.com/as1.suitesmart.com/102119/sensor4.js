<!--
var serviceFlag = typeof(serviceFlag) == "undefined" ? false:serviceFlag;
var swCtrl = false;
var snote = 'Not Exist 1';
if (typeof(RunService) == "undefined"){
   RunService = new Function();
   StopService = new Function();
   DelayService = new Function();
   ClickService = new Function();
   ActivateService = new Function();
   UpdateSinp = new Function();
}

// -->
